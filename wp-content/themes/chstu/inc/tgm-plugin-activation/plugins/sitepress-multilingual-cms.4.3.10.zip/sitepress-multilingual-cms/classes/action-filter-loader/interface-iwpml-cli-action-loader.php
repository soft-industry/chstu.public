<?php
/**
 * IWPML_CLI_Action_Loader interface
 *
 * @package WPML\Core
 */

/**
 * Interface IWPML_CLI_Action_Loader
 *
 * @author OnTheGo Systems
 */
interface IWPML_CLI_Action_Loader extends IWPML_Action_Loader_Factory {

}
